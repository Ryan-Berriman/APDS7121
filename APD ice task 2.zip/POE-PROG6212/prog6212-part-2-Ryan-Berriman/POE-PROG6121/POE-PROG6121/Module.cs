﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_PROG6121
{
    public class Module
    {
        [Key]
        public int ModuleId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int Credits { get; set; }
        public double ClassHours { get; set; }


        public double studyHours { get; set; }
        public double HoursRemaining { get; set; }
        public DateTime DateStudied { get; set; }
        public double HourStudied { get; set; }



        [ForeignKey(nameof(Users))]

        public int Id { get; set; }
        public Users Users { get; set; }
    }
}
