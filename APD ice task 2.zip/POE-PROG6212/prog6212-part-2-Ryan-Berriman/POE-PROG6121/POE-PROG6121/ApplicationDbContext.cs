﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace POE_PROG6121
{
    public class  ApplicationDbContext : DbContext
    {

        public DbSet<Semesters> Semester { get; set; }


        // then build the solution

        //then enable-migrations
        // then add-migration SemTableMig

        // -- if database exists just update

        // then update-database
        public DbSet<Module> Modules { get; set; }

        public DbSet<Users> Users { get; set; }
       

    }
}
