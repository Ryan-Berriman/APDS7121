﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE_PROG6121
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {


        public Login()
        {
            InitializeComponent();
        }

        //global connection string

        //Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Task2EF.ApplicationDbContext;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False;

        string ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=POE_PROG6121.ApplicationDbContext;Integrated Security=True;";



        //method validation user against the db

        public bool ValidateUser(string username, string password)
        {

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {

                connection.Open();
                //sql injections to read from the tables
                string query = "SELECT COUNT(*) FROM [Users] WHERE Username = @Username AND Password = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {

                        //user is valid
                        return true;
                    }
                }
            }
            return false;
        }

        private void backBTN_Click(object sender, RoutedEventArgs e)
        {
            //back button 
            MainUserPage landing = new MainUserPage();
            this.Hide();
            landing.Show();
        }

        private void LoginBTN_Click(object sender, RoutedEventArgs e)
        {
            //login button code

            string enterUsername = usernameTB.Text;
            string enteredPassword = passwordTB.Password.ToString();

            //variable to hold the hashed password
            string hashedEnteredPassword = HashPassword(enteredPassword);

            // if (ValidateUser(enterUsername, hashedEnteredPassword))
            // now you can validate
            if (ValidateUser(enterUsername, hashedEnteredPassword))
            {
                using (var context = new ApplicationDbContext())
                {

                    Users Found = context.Users.FirstOrDefault(r => r.Username == enterUsername && r.Password == hashedEnteredPassword);

                    MessageBox.Show("Login successful - you can now capture info");

                    MainWindow main = new MainWindow(Found.UserID);
                    this.Hide();
                    main.Show();
                }


            }
            else
            {
                MessageBox.Show("Login failed - check spelling!");
            }
        }




        //method to hash

        private string HashPassword(string password)
        {

            using (SHA256 sHA256 = SHA256.Create())
            {
                byte[] hashBytes = sHA256.ComputeHash(Encoding.UTF8.GetBytes(password));

                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }

        }

        private void UsernameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (usernameTB.Text == "Username")
            {
                usernameTB.Text = "";
            }
        }

        private void UsernameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(usernameTB.Text))
            {
                usernameTB.Text = "Username";
            }
        }

        private void usernameTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            SolidColorBrush myBrush = new SolidColorBrush(Color.FromArgb(0xFF, 0x8A, 0xF9, 0x9D));
            if (usernameTB.Text == "Username")
            {
                usernameTB.Foreground = myBrush; ;
            }
            else
            {
                usernameTB.Foreground = myBrush;
            }
        }


    }
}
