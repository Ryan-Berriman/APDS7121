﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE_PROG6121
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {

        public string ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=POE_PROG6121.ApplicationDbContext;Integrated Security=True;";

        //method to hash

        private string HashPassword(string password)
        {

            using (SHA256 sHA256 = SHA256.Create())
            {
                byte[] hashBytes = sHA256.ComputeHash(Encoding.UTF8.GetBytes(password));

                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2"));
                }

                return builder.ToString();
            }
        }


        public Register()
        {
            InitializeComponent();
        }

        private void BackBTN_Click(object sender, RoutedEventArgs e)
        {
            //back button 
            MainUserPage landing = new MainUserPage();
            this.Hide();
            landing.Show();
        }

        private void RegisterBTN_Click(object sender, RoutedEventArgs e)
        {
            //first fetch all the text from the TB's

            string username = UsernameTB.Text;
            string password = PasswordTB.Password;
            string confirmPassword = ConPasswordTB.Password;
            string email = EmailTB.Text;

            //NB PASSWORD && CONFIRMATION PASSWORD MUST BE THE SAME


            if (password == confirmPassword)
            {

                //now hash them
                string hashedPassword = HashPassword(password);
                // now you can pass onto the db
                //first create the sql connection

                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    // now create the query to put the data into the tables

                    string query = "INSERT INTO [Users] (Username, Email, Password) VALUES (@Username, @Email, @Password)";

                    // now pass the query into a sqlcommand

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Password", hashedPassword);

                        //execute query
                        command.ExecuteNonQuery();
                        //optional notification
                        MessageBox.Show("User registration successful");


                        MainUserPage landing = new MainUserPage();
                        this.Hide();
                        landing.Show();

                    }// using command ends

                }//using sql connection ends


            }//if statement ends

            else
            {
                MessageBox.Show("Registration failed! Passwords were not the same!");
            }






        }

        private void UsernameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (UsernameTB.Text == "Username")
            {
                UsernameTB.Text = "";
            }
        }

        private void UsernameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UsernameTB.Text))
            {
                UsernameTB.Text = "Username";
            }
        }

        private void usernameTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            SolidColorBrush myBrush = new SolidColorBrush(Color.FromArgb(0xFF, 0x8A, 0xF9, 0x9D));

            if (UsernameTB.Text == "Username")
            {
                UsernameTB.Foreground = myBrush;
            }
            else
            {
                UsernameTB.Foreground = myBrush;
            }
        }

        private void EmailTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (EmailTB.Text == "Email")
            {
                EmailTB.Text = "";
            }
        }

        private void EmailTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EmailTB.Text))
            {
                EmailTB.Text = "Email";
            }
        }

        private void emailTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            SolidColorBrush myBrush = new SolidColorBrush(Color.FromArgb(0xFF, 0x8A, 0xF9, 0x9D));

            if (EmailTB.Text == "Email")
            {
                EmailTB.Foreground = myBrush;
            }
            else
            {
                EmailTB.Foreground = myBrush;
            }
        }

        private void ShowPassword_Checked(object sender, RoutedEventArgs e)
        {
            visiblePasswordBox.Text = PasswordTB.Password;
            visiblePasswordBox.Visibility = Visibility.Visible;
            PasswordTB.Visibility = Visibility.Collapsed;

            PasswordTB.Password = (visiblePasswordBox.Text).ToString();

            VisiblePasswordBox.Text = ConPasswordTB.Password;
            VisiblePasswordBox.Visibility = Visibility.Visible;
            ConPasswordTB.Visibility = Visibility.Collapsed;

            ConPasswordTB.Password = (VisiblePasswordBox.Text).ToString();
        }

        private void ShowPassword_Unchecked(object sender, RoutedEventArgs e)
        {
            visiblePasswordBox.Visibility = Visibility.Collapsed;
            PasswordTB.Visibility = Visibility.Visible;
            PasswordTB.Password = (visiblePasswordBox.Text).ToString();

            VisiblePasswordBox.Visibility = Visibility.Collapsed;
            ConPasswordTB.Visibility = Visibility.Visible;
            ConPasswordTB.Password = (VisiblePasswordBox.Text).ToString();
        }


    }
}
