﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_PROG6121
{
    public class ModuleAndSem
    {
        private string moduleName;
        private string moduleCode;
        private int numberOfCredits;
        private Double classHours;
        private Double hoursNeeded;
        private Double recentHours;
        private string currentDate;
        private Double Hremaining;

        //bools for checks

        private static bool moduleNameBool;

        private static bool moduleCodeBool;

        private static bool numberOfCreditsBool;

        private static bool classHoursBool;

        //LISTS
        private static List<string> moduleListName = new List<string>();
        private static List<string> moduleCodeName = new List<string>();
        private static List<string> numberOfCreditList = new List<string>();
        private static List<Double> moduleClassHourList = new List<Double>();
        private static List<Double> moduleHoursNeededList = new List<Double>();
        private static List<Double> moduleRecentHoursList = new List<Double>();
        private static List<string> moduleCurrentDateList = new List<string>();
        private static List<Double> moduleHremainingList = new List<Double>();

        // date variables

        // public static DateTime currentDate;
        public static DateTime currentWeekStartDate;
        public static DateTime currentWeekEndDate;


        public Double hremaining { get => Hremaining; set => Hremaining = value; }
        public string CurrentDate { get => currentDate; set => currentDate = value; }
        public Double RecentHours { get => recentHours; set => recentHours = value; }
        public Double HoursNeeded { get => hoursNeeded; set => hoursNeeded = value; }
        public string ModuleName { get => moduleName; set => moduleName = value; }
        public string ModuleCode { get => moduleCode; set => moduleCode = value; }
        public int NumberOfCredits { get => numberOfCredits; set => numberOfCredits = value; }
        public Double ClassHours { get => classHours; set => classHours = value; }
        public static bool ModuleNameBool { get => moduleNameBool; set => moduleNameBool = value; }
        public static bool ModuleCodeBool { get => moduleCodeBool; set => moduleCodeBool = value; }
        public static bool NumberOfCreditsBool { get => numberOfCreditsBool; set => numberOfCreditsBool = value; }
        public static bool ClassHoursBool { get => classHoursBool; set => classHoursBool = value; }
        public static List<string> ModuleListName { get => moduleListName; set => moduleListName = value; }
        public static List<string> ModuleCodeName { get => moduleCodeName; set => moduleCodeName = value; }
        public static List<string> NumberOfCreditList { get => numberOfCreditList; set => numberOfCreditList = value; }
        public static List<Double> ModuleClassHourList { get => moduleClassHourList; set => moduleClassHourList = value; }
        public static List<double> ModuleHoursNeededList { get => moduleHoursNeededList; set => moduleHoursNeededList = value; }

        public string SemesterNumber { get; internal set; }
        public bool Semesterbool { get; internal set; }
        public int SemesterWeeks { get; internal set; }
        public bool SemesterWeeksbool { get; internal set; }
        public DateTime SemesterStartDate { get; internal set; }
        public bool SemesterStartDateBool { get; internal set; }
        public DateTime SemesterEndDate { get; internal set; }
        public bool SaveSemInfoBtnWasClicked { get; internal set; }



        // this will be needed for binding - esp between wpf windows and objects
    }
}
