﻿namespace POE_PROG6121.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FirstMigNew : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Modules",
                c => new
                    {
                        ModuleId = c.Int(nullable: false, identity: true),
                        Code = c.String(),
                        Name = c.String(),
                        Credits = c.Int(nullable: false),
                        ClassHours = c.Double(nullable: false),
                        studyHours = c.Double(nullable: false),
                        HoursRemaining = c.Double(nullable: false),
                        DateStudied = c.DateTime(nullable: false),
                        HourStudied = c.Double(nullable: false),
                        Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ModuleId)
                .ForeignKey("dbo.Users", t => t.Id, cascadeDelete: true)
                .Index(t => t.Id);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        UserID = c.Int(nullable: false, identity: true),
                        Username = c.String(nullable: false),
                        Email = c.String(),
                        Password = c.String(),
                    })
                .PrimaryKey(t => t.UserID);
            
            CreateTable(
                "dbo.Semesters",
                c => new
                    {
                        SemesterId = c.Int(nullable: false, identity: true),
                        SemesterName = c.String(),
                        Weeks = c.Int(nullable: false),
                        StartDate = c.DateTime(nullable: false),
                        Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SemesterId)
                .ForeignKey("dbo.Users", t => t.Id, cascadeDelete: true)
                .Index(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Semesters", "Id", "dbo.Users");
            DropForeignKey("dbo.Modules", "Id", "dbo.Users");
            DropIndex("dbo.Semesters", new[] { "Id" });
            DropIndex("dbo.Modules", new[] { "Id" });
            DropTable("dbo.Semesters");
            DropTable("dbo.Users");
            DropTable("dbo.Modules");
        }
    }
}
