﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_PROG6121
{
    public class Semesters { 
        [Key]
    public int SemesterId { get; set; }
    public string SemesterName { get; set; }
    public int Weeks { get; set; }
    public DateTime StartDate { get; set; }


        [ForeignKey(nameof(Users))]

        public int Id { get; set; }
        public Users Users { get; set; }
    }
}
