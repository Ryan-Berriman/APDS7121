﻿using CalcMain;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace POE_PROG6121
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int currentUser;
        public MainWindow(int User)
        {
            currentUser = User;
            InitializeComponent();
            LoadDataIntoDataGrid();

        }


        private void LoadDataIntoDataGrid()
        {
            using (var context = new ApplicationDbContext())
            {
                int userId = currentUser;
                var filteredData = context.Modules.Where(m => m.Id == currentUser).ToList();
                DataGridModules.ItemsSource = null;
                DataGridModules.ItemsSource = filteredData;
            }
        }



        //global object of the class
        Semesters sem = new Semesters();
        // this is the variable for working out the hours needed for self study of the user
        public double solution = 0;

        //observable collection
        private ObservableCollection<Semesters> sem_Info = new ObservableCollection<Semesters>();

        // this button saves the inputted data the user has entered for a Semester 
        private void AddSemInfoBtn_Click(object sender, RoutedEventArgs e)
        {

            //try catch method so the program doesnt end and re-prompts the user
            try
            {
                // combo box save
                string selectedSem = SemesterComboBox.Text;

                //text box save
                int numOfWeeks = int.Parse(SemesterWeekTextBox.Text);
                sem.Weeks = numOfWeeks;

                //date picker save
                DateTime selectDate = StartDate.SelectedDate.GetValueOrDefault();

                //convert them all to string
                string infoMsg = $"Semester: {selectedSem}\n" +
                                 $"Weeks: {numOfWeeks} \n" +
                                 $"Start Date: {selectDate.ToShortDateString()}";

                //pass the msg inot a mbox
                MessageBox.Show(infoMsg, "Semester Information");

                #region nash Sem
                try
                {

                    if (SemesterComboBox.SelectedItem is ComboBoxItem selectedSemesterItemer)
                    {
                        using (var context = new ApplicationDbContext())
                        {
                            var semester = new Semesters
                            {
                                SemesterName = selectedSemesterItemer.Content.ToString(),
                                Weeks = Convert.ToInt32(SemesterWeekTextBox.Text),
                                StartDate = StartDate.SelectedDate.Value,

                                Id = currentUser



                            };
                            context.Semester.Add(semester);
                            context.SaveChanges();
                            MessageBox.Show("Saved to the Database");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Failed to save data");
                    }

                }
                catch (Exception a)
                {

                    MessageBox.Show(a.ToString());

                }
                #endregion

                // this makes the semester input boxes read only as they only need to enter 1 semester at a time 
                RestartBTN.Visibility = Visibility.Visible;
                AddSemInfoBtn.IsEnabled = false;
                SemesterComboBox.IsReadOnly = true;
                SemesterWeekTextBox.IsReadOnly = true;
                SemesterWeekTextBox.IsReadOnly = true;
            }
            catch (Exception)
            {

                MessageBox.Show("Enter correct information!!!", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        // this button saves the inputted data the user has entered for a module 
        private void AddModuleBtn_Click(object sender, RoutedEventArgs e)
        {

            //try catch method so the program doesnt end and re-prompts the user
            try
            {
                //another check to ensure the user has entered information into each box
                if (!ModuleCodeTextBox.Text.Equals(null) || !ModuleNameTextBox.Text.Equals(null) || !CreditNumberTextBox.Text.Equals(null) || !ClassHoursTextBox.Text.Equals(null))
                {

                    //follows the flow of logic and makes the next set of features available
                    SelectLB.Visibility = Visibility.Visible;
                    Fetch.Visibility = Visibility.Visible;
                    
                    // this calculates the hours needed for self study fromn the user based off inputted data
                    Double solution = Math.Round(Class1.calcWeeklyStudy(int.Parse(CreditNumberTextBox.Text), sem.Weeks, int.Parse(ClassHoursTextBox.Text)));


                    //takes the inputted data from the text boxes and passes them into local variables to be stored and used within the program
                    string moduleCode = ModuleCodeTextBox.Text;
                    string moduleName = ModuleNameTextBox.Text;
                    int numCredits = int.Parse(CreditNumberTextBox.Text);
                    Double classHours = Double.Parse(ClassHoursTextBox.Text);

                    Double HoursRem = solution;

                    //now pull the mod&sem objects
                    //get them to point to the same thing in memory
                    Module Module = new Module
                    {
                        Code = moduleCode,
                        Name = moduleName,
                        Credits = numCredits,
                        ClassHours = classHours,
                        studyHours = solution,
                        HourStudied = 0,
                        DateStudied = DateTime.Now,
                        HoursRemaining = HoursRem,

                    };

                    // Display the variables in a MessageBox
                    string message = $"Module Code: {Module.Code}\n" +
                                     $"Module Name: {Module.Name}\n" +
                                     $"Number of Credits: {Module.Credits}\n" +
                                     $"Class Hours: {Module.ClassHours}\n" +
                                     $"Hours Needed: {Module.studyHours}\n" +
                                     $"Recent Hours: {Module.HourStudied}\n" +
                                     $"Current Date: {Module.DateStudied}\n" +
                                     $"Hours Remaining: {Module.HoursRemaining}";

                    MessageBox.Show(message, "Module Information", MessageBoxButton.OK, MessageBoxImage.Information);


                    #region nash Mod
                    try
                    {
                      
                        using (var context = new ApplicationDbContext())
                        {
                            var filterData = context.Modules.Where(t => t.Id == currentUser).ToList();
                            var Modules = new Module()
                            {
                                Code = ModuleCodeTextBox.Text,
                                Name = ModuleNameTextBox.Text,
                                Credits = int.Parse(CreditNumberTextBox.Text),
                                ClassHours = Double.Parse(ClassHoursTextBox.Text),
                                studyHours = solution,
                                HoursRemaining = HoursRem,
                                DateStudied = DateTime.Now,
                                HourStudied = 0,
                                Id = currentUser,
                            };

                            context.Modules.Add(Modules);
                            context.SaveChanges();

                            DataGridModules.ItemsSource = filterData;
                            MessageBox.Show("Saved to db");
                        }
                        LoadDataIntoDataGrid();
                    }


                    catch (Exception a)
                    {

                        MessageBox.Show(a.ToString());

                    }
                    #endregion


                    //puts the data into the datagrid

                    LoadDataIntoDataGrid();
                    DataGridModules.Items.Refresh();


                    // clear the text boxs
                    ModuleCodeTextBox.Clear();
                    ModuleNameTextBox.Clear();
                    CreditNumberTextBox.Clear();
                    ClassHoursTextBox.Clear();
                    SemesterWeekTextBox.Clear();


                }

            }
            catch (Exception)
            {
                //error message
                MessageBox.Show("Enter the correct information!!!", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);

            }

        }

        private void ViewBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        // this is the data grid
        private void DataGridModules_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

            // Checks to see if any cell is selected in the DataGrid
            if (DataGridModules.SelectedCells.Count > 0)
            {
                // uses the selected cell the user chose
                DataGridCellInfo selectedCell = DataGridModules.SelectedCells[0];

                // Checks to see if the selected cell contains a moduleInfo object
                if (selectedCell.Item is ModuleAndSem moduleInfo)
                {
                    // Uses the properties of the moduleInfo object
                    ModuleCodeTextBox.Text = moduleInfo.ModuleCode;
                    ModuleNameTextBox.Text = moduleInfo.ModuleName;
                    CreditNumberTextBox.Text = moduleInfo.NumberOfCredits.ToString();
                    ClassHoursTextBox.Text = moduleInfo.ClassHours.ToString();

                }
            }
        }

        //this button is so the user can enter their study hours on a certain date and it then updates the data in the data grid and how many hours remains of self study needed.
        private void UpdateHoursBTN_Click(object sender, RoutedEventArgs e)
        {
            //try catch method so the program doesnt end and re-prompts the user
             try
             {
            // hides and shows certain buttons and input requests in order to guide the user through the flow of the program
            SelectLB.Visibility = Visibility.Visible;
            Fetch.Visibility = Visibility.Visible;

            NumHoursLB.Visibility = Visibility.Hidden;
            RecentHoursTB.Visibility = Visibility.Hidden;
            StudyDateLB.Visibility = Visibility.Hidden;
            RecentDate.Visibility = Visibility.Hidden;
            UpdateHoursBTN.Visibility = Visibility.Hidden;
            UpdateLB.Visibility = Visibility.Hidden;


            //int ModCredits;
            //if (int.TryParse(CredBox.Text, out ModCredits))
            //{
            //    // Parsing was successful, ModCredits now contains the integer value.
            //}

            //Double ClassHours;
            //if (Double.TryParse(WCHbox.Text, out ClassHours))
            //{
            //    // Parsing was successful, ModCredits now contains the integer value.
            //}

            //Double remain;
            //if (Double.TryParse(WCHbox.Text, out remain))
            //{
            //    // Parsing was successful, ModCredits now contains the integer value.
            //}


            //these text boxes store the local variables in them for when certain information is being updated by the user
            string ModCode = MCbox.Text;
            string ModName = MNbox.Text;
            int ModCredits = int.Parse(CredBox.Text);
            Double ClassHours = Double.Parse(WCHbox.Text);
            Double remain = Double.Parse(HRbox.Text);

            string HStudy2 = RecentHoursTB.Text;
            // this is to ensure no logical language errors occur for a double being misinterpreted
            
            string ReplaceExcept = HStudy2.Replace(".", ",");
            if (double.TryParse(ReplaceExcept, out Double HStudy))
            {

            }
            else
            {
                HStudy = Double.Parse(RecentHoursTB.Text);
            }


            //translating the date
            DateTime RecDay = RecentDate.SelectedDate.GetValueOrDefault();

            // Calculation class library
            Double solution = Math.Round(Class1.calcWeeklyStudy(ModCredits, sem.Weeks, ClassHours));

            // This calculates the remaining hours
            Double HourRem = remain - HStudy;



            using (var context = new ApplicationDbContext())
            {

                // This searches for an existing moduleInfo object with the same ModuleCode from the users input
                Module existingModule = context.Modules.FirstOrDefault(m => m.Code == ModCode);

                if (existingModule != null)
                {

                    // If an existing module with the same ModuleCode is found,then this will update its properties

                    existingModule.Name = ModName;
                    existingModule.Credits = ModCredits;
                    existingModule.ClassHours = ClassHours;
                    existingModule.HourStudied = solution;
                    existingModule.studyHours = HStudy;
                    existingModule.DateStudied = RecDay;
                    existingModule.HoursRemaining = HourRem;


                    

                    context.SaveChanges();


                     //try
                    //  {
                    // Update your data
                    // context.SaveChanges();
                    // }
                    //  catch (DbUpdateException ex)
                    //  {
                    // var innerException = ex.InnerException;
                    // Handle or log the specific database error here
                    // }

                    // This updates the datagrid so the changes are visible
                    //DataGridModules.ItemsSource = (System.Collections.IEnumerable)existingModule;


                    MessageBox.Show("Yes");

                }
                else
                {
                    // If no existing module with the same ModuleCode is found, create a new one
                    ModuleAndSem newModule = new ModuleAndSem()
                    {
                        ModuleCode = ModCode,
                        ModuleName = ModName,
                        NumberOfCredits = ModCredits,
                        ClassHours = ClassHours,
                        HoursNeeded = solution,
                        RecentHours = HStudy,
                        CurrentDate = RecDay.ToShortDateString(),
                        hremaining = HourRem,

                    };
                    MessageBox.Show("No");
                    // This adds the new module to the collection
                    // mod_Info.Add(newModule);

                    // This then updates the DataGrid to reflect the changes

                }




                LoadDataIntoDataGrid();
                //context.SaveChanges();



            };


            // clears the hidden storage text boxes for when the user wants to select a new row in the data grid to update
            MCbox.Clear();
            MNbox.Clear();
            CredBox.Clear();
            WCHbox.Clear();
            RecentHoursTB.Clear();

            HRbox.Clear();

            RecentDate.Text = string.Empty;


             }
              catch (Exception)
              {
            //error message
            MessageBox.Show("Enter the correct information!!!", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
              }


        }

        // this button fetches the variables in the selected row and translates them to text boxes temporarily
        private void Fetch_Click(object sender, RoutedEventArgs e)
        {

            //try catch method so the program doesnt end and re-prompts the user
            try
            {
                // hides and shows certain buttons and input requests in order to guide the user through the flow of the program
                SelectLB.Visibility = Visibility.Hidden;
                Fetch.Visibility = Visibility.Hidden;

                NumHoursLB.Visibility = Visibility.Visible;
                RecentHoursTB.Visibility = Visibility.Visible;
                StudyDateLB.Visibility = Visibility.Visible;
                RecentDate.Visibility = Visibility.Visible;
                UpdateHoursBTN.Visibility = Visibility.Visible;
                UpdateLB.Visibility = Visibility.Visible;


                if (DataGridModules.SelectedCells.Count > 0)
                {
                    // This checks to see if any cell is selected in the DataGrid
                    DataGridCellInfo selectedCell = DataGridModules.SelectedCells[0];





                    //This uses the selected cell the user chose
                    if (selectedCell.Item is Module Modules)
                    {
                        // Uses the properties of the module object
                        MCbox.Text = Modules.Code;
                        MNbox.Text = Modules.Name;

                        CredBox.Text = Modules.Credits.ToString();
                        WCHbox.Text = Modules.ClassHours.ToString();

                        HRbox.Text = Modules.HoursRemaining.ToString();
                        SSHNbox.Text = Modules.studyHours.ToString();
                        // You can set other TextBoxes with additional properties here
                        // HoursU.Text = moduleInfo.HoursStudied.ToString();
                    }
                }
            }
            catch (Exception)
            {
                //error message
                MessageBox.Show("Enter the correct information!!!", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DataGridModulesUpdated_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {



        }

        // this button is so that ifd the user has moved on to a new semester they will be able to  press the restart button to clear all data on the program and start fresh without having to re open the program
        private void RestartBTN_Click(object sender, RoutedEventArgs e)
        {

            RestartBTN.Visibility = Visibility.Hidden;
            AddSemInfoBtn.IsEnabled = true;
            SemesterComboBox.IsReadOnly = false;
            SemesterWeekTextBox.IsReadOnly = false;
            SemesterWeekTextBox.IsReadOnly = false;

            sem_Info.Clear();
            DataGridModules.Items.Refresh();

            MCbox.Clear();
            MNbox.Clear();
            CredBox.Clear();
            WCHbox.Clear();
            RecentHoursTB.Clear();

            HRbox.Clear();

            RecentDate.Text = string.Empty;

            ModuleCodeTextBox.Clear();
            ModuleNameTextBox.Clear();
            CreditNumberTextBox.Clear();
            ClassHoursTextBox.Clear();
            SemesterWeekTextBox.Clear();

            SelectLB.Visibility = Visibility.Hidden;
            Fetch.Visibility = Visibility.Hidden;

            NumHoursLB.Visibility = Visibility.Hidden;
            RecentHoursTB.Visibility = Visibility.Hidden;
            StudyDateLB.Visibility = Visibility.Hidden;
            RecentDate.Visibility = Visibility.Hidden;
            UpdateHoursBTN.Visibility = Visibility.Hidden;
            UpdateLB.Visibility = Visibility.Hidden;


        }

        private void DataGridModules_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void SignOutBTN_Click(object sender, RoutedEventArgs e)
        {

            MainUserPage main = new MainUserPage();
            this.Close();
            main.Show();

        }
    }
}
