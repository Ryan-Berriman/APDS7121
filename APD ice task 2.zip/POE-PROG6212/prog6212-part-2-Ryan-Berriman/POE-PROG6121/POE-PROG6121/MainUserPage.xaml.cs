﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE_PROG6121
{
    /// <summary>
    /// Interaction logic for MainUserPage.xaml
    /// </summary>
    public partial class MainUserPage : Window
    {
        public MainUserPage()
        {
            InitializeComponent();
        }

        private void LoginBTN_Click(object sender, RoutedEventArgs e)
        {
            //go to login page

            Login logs = new Login();
            this.Hide();
            logs.Show();

        }

        private void RegisterBTN_Click(object sender, RoutedEventArgs e)
        {
            Register reg = new Register();
            this.Hide();
            reg.Show();
        }

    }
}
