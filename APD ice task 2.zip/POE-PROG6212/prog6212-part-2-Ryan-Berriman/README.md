##  INSTRUCTIONS FOR USING MY PROGRAM:

When the user runs the program they will see a user page showing whether they would like to login or register, if this is the users first time using the application then they will need to select the register button which will then take them to a register page to full in their details and it will sav it to a database. They will then be able to login wiht their details of username and password and they will then be taken into the main window page. 

They will then be prompted to an add semester section and an add module section. The user must first drop down the selection box and select whether they are in semester 1 or 2, they then enter the number of weeks in that semester and the starting date of the semester. Once they have filled in that data they must then press the 'Add Semester info' button which will then show a message box with the inputted information to show it has been saved.

The user then adds the modules for that semester. they first input the module code for the module, then the name of the specific module. The number of credits and the number of class hours per week for the specific module. They then press the 'Add Module' button and it will displayed the inputted information to show it has been saved. the user will then be able to add multiple modules which will also be saved in the data grid and will also be displayed in it.

Also in the backround the application will work out how many hours of self study will be required from the user per semester based on the number of weeks they have given, the hours per week and the credits for each module. it will create these statistics after a user presses the 'Add Module' button in the data grid. 

The user will then be prompted to fetch a module from the data grid. so the user will click on the data grid row for a module they would like to update. they will then press the 'fetch' button and a text box will appear to the user to input the number of hours they have studied for that specific module and on what date. When the user presses the 'update' button it will refresh the datagrid and show the recent hours studied and the date. it will also subtract the recent hours studied from the remaining self hours studied column in the data grid row, for that specific module keeping it updated with each submission. A user cn keep updating modules as much as they like.

when the user is ready for the next semester they will be able to press a button called 'restart' which will appear next to the 'Add Semester info' button when it is pressed. The restart button clears the data grid and basically gets the program back to the beginning without having to rerun the program.


## CHANGES LOGS

- added in a login register page.

- register page grabs information.

- login page check if the data is valid for username and password and allows the user in.

- added a database to catch all the data and created the corresponding tables such as USER, MODULES, SEMESTERS. 

## HARWARE REQUIREMENTS FOR MY PROGRAM: 

Operating System: Windows 7 or later. Windows 10 is a commonly used platform for WPF development.

Processor: An Intel Core i3/i5/i7 or equivalent AMD processor.

RAM: At least 4 GB of RAM is recommended, but more RAM may be necessary for complex applications but will suffice for the WPF.

Storage: Sufficient storage space for Visual Studio and your project files. An SSD (Solid-State Drive) can significantly improve performance.

## SOFTWARE REQUIREMENTS: 

Visual Studio: You'll need Visual Studio installed on your system. The version of Visual Studio dthat is recommended for WPF development is Visual Studio 2019 or later.

.NET Framework or .NET Core/5/6: WPF applications can target the traditional .NET Framework or .NET Core/5/6, depending on your project's requirements.

Windows SDK: Ensure that you have the Windows Software Development Kit (SDK) installed for the target Windows version you are developing for.

Optional: Depending on your project's requirements, you may need additional libraries, components, or tools.

## FAQ’s :

Q1) Will the program break if I enter a null value?

A1) No, as there are multiple try catch methods that reprompt the user to enter valid information
Q2) What if the user enters a double for their hours studied?

A2) The program recognises it and adjusts the hours remaining as a double with reference to 1 decimal place.

Q3) Can the program recognise the difference between "," and a "." for the double?

A3) I have avoided this language error by when the user enters a double with a comma for the double it will recognise it and convert it to a fullstop to correct the language and save the variable, as well as calculate with it accordingly.

Q4) If i re open a window will my data be saved?

A4) Yes the program now has a database so it will save the values.

Q5) Can other users see my data?

A5) No other users will not be able to see your personal logged data as the data is tied to the user.

## CODE ATTRIBUTIONS:

```
<Window x:Class="POE_PROG6121.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
        xmlns:local="clr-namespace:POE_PROG6121


using CalcMain;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
```

## ADMIN DETAILS: 
Name: Ryan Berriman Student Number: ST10044691 Student Email: ST10044691@vcconnect.edu.za


## REFERENCES: 

STACK OVERFLOW
• Best ways to format LINQ queries (2012) Stack Overflow. Available at: https://stackoverflow.com/questions/2924490/best-ways-to-format-linq-queries (Accessed: 19 September 2023). 

• How to show a custom error or warning message box in .net winforms? (2009) Stack Overflow. Available at: https://stackoverflow.com/questions/2109441/how-to-show-a-custom-error-or-warning-message-box-in-net-winforms (Accessed: 18 September 2023). 

GITHUB
• https://github.com/VCWVL/prog6212-part-2-Ryan-Berriman








